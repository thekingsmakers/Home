﻿<#

.LINK
    http://psappdeploytoolkit.com
#>
[CmdletBinding()]
Param (
    [Parameter(Mandatory=$false)]
    [ValidateSet('Install','Uninstall','Repair')]
    [string]$DeploymentType = 'Install',
    [Parameter(Mandatory=$false)]
    [ValidateSet('Interactive','Silent','NonInteractive')]
    [string]$DeployMode = 'Interactive',
    [Parameter(Mandatory=$false)]
    [switch]$AllowRebootPassThru = $false,
    [Parameter(Mandatory=$false)]
    [switch]$TerminalServerMode = $false,
    [Parameter(Mandatory=$false)]
    [switch]$DisableLogging = $false
)

Try {
    ## Set the script execution policy for this process
    Try { Set-ExecutionPolicy -ExecutionPolicy 'ByPass' -Scope 'Process' -Force -ErrorAction 'Stop' } Catch {}

    ##*===============================================
    ##* VARIABLE DECLARATION
    ##*===============================================
    ## Variables: Application
    [string]$appVendor = ''
    [string]$appName = 'WPS Office Uninstall'
    [string]$appVersion = ''
    [string]$appArch = ''
    [string]$appLang = ''
    [string]$appRevision = ''
    [string]$appScriptVersion = '1.0.0'
    [string]$appScriptDate = 'XX/XX/20XX'
    [string]$appScriptAuthor = 'Jason Bergner'
    ##*===============================================
    ## Variables: Install Titles (Only set here to override defaults set by the toolkit)
    [string]$installName = ''
    [string]$installTitle = 'Kingsoft Corp. WPS Office Uninstall'

    ##* Do not modify section below
    #region DoNotModify

    ## Variables: Exit Code
    [int32]$mainExitCode = 0

    ## Variables: Script
    [string]$deployAppScriptFriendlyName = 'Deploy Application'
    [version]$deployAppScriptVersion = [version]'3.8.4'
    [string]$deployAppScriptDate = '26/01/2021'
    [hashtable]$deployAppScriptParameters = $psBoundParameters

    ## Variables: Environment
    If (Test-Path -LiteralPath 'variable:HostInvocation') { $InvocationInfo = $HostInvocation } Else { $InvocationInfo = $MyInvocation }
    [string]$scriptDirectory = Split-Path -Path $InvocationInfo.MyCommand.Definition -Parent

    ## Dot source the required App Deploy Toolkit Functions
    Try {
        [string]$moduleAppDeployToolkitMain = "$scriptDirectory\AppDeployToolkit\AppDeployToolkitMain.ps1"
        If (-not (Test-Path -LiteralPath $moduleAppDeployToolkitMain -PathType 'Leaf')) { Throw "Module does not exist at the specified location [$moduleAppDeployToolkitMain]." }
        If ($DisableLogging) { . $moduleAppDeployToolkitMain -DisableLogging } Else { . $moduleAppDeployToolkitMain }
    }
    Catch {
        If ($mainExitCode -eq 0){ [int32]$mainExitCode = 60008 }
        Write-Error -Message "Module [$moduleAppDeployToolkitMain] failed to load: `n$($_.Exception.Message)`n `n$($_.InvocationInfo.PositionMessage)" -ErrorAction 'Continue'
        ## Exit the script, returning the exit code to SCCM
        If (Test-Path -LiteralPath 'variable:HostInvocation') { $script:ExitCode = $mainExitCode; Exit } Else { Exit $mainExitCode }
    }

    #endregion
    ##* Do not modify section above
    ##*===============================================
    ##* END VARIABLE DECLARATION
    ##*===============================================

    If ($deploymentType -ine 'Uninstall' -and $deploymentType -ine 'Repair') {
        ##*===============================================
        ##* PRE-INSTALLATION
        ##*===============================================
        [string]$installPhase = 'Pre-Installation'
  
        ##*===============================================
        ##* INSTALLATION
        ##*===============================================
        [string]$installPhase = 'Installation'

        ##*===============================================
        ##* POST-INSTALLATION
        ##*===============================================
        [string]$installPhase = 'Post-Installation'

    }
    ElseIf ($deploymentType -ieq 'Uninstall')
    {
        ##*===============================================
        ##* PRE-UNINSTALLATION
        ##*===============================================
        [string]$installPhase = 'Pre-Uninstallation'

        ## Show Welcome Message, Close WPS Office With a 60 Second Countdown Before Automatically Closing
        Show-InstallationWelcome -CloseApps 'ksolaunch,ksomisc,wpp,wps,wpscenter,wpscloudlaunch,wpscloudsvr,wpsoffice,wpspdf,wpsupdate' -CloseAppsCountdown 60

        ## Show Progress Message (With a Message to Indicate the Application is Being Uninstalled)
        Show-InstallationProgress -StatusMessage "Uninstalling Any Existing Version of WPS Office Please Wait..."

        ##*===============================================
        ##* UNINSTALLATION
        ##*===============================================
        [string]$installPhase = 'Uninstallation'

        ## Remove WPS Office (User Profile)
        $Users = Get-ChildItem C:\Users
        foreach ($user in $Users){

        $WPSLocal = "$($user.fullname)\AppData\Local\Kingsoft\WPS Office"
        If (Test-Path $WPSLocal) {

        $UninstPath = Get-ChildItem -Path "$WPSLocal\*" -Include uninst.exe -Recurse -ErrorAction SilentlyContinue
        If($UninstPath.Exists)
        {
        Write-Log -Message "Found $($UninstPath.FullName), now attempting to uninstall $installTitle."
        Execute-ProcessAsUser -Path "$UninstPath" -Parameters "/S" -Wait
        Get-Process -Name "Au_" -ErrorAction SilentlyContinue | Wait-Process

        ## Cleanup User Profile Registry
        [scriptblock]$HKCURegistrySettings = {
        Remove-RegistryKey -Key 'HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\Kingsoft Office' -SID $UserProfile.SID
        }
        Invoke-HKCURegistrySettingsForAllUsers -RegistrySettings $HKCURegistrySettings -ErrorAction SilentlyContinue
        }
        }
        }
        ## Restart Explorer.exe
        Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue

        $ExplorerProcess = Get-Process Explorer -ErrorAction SilentlyContinue
        If($ExplorerProcess -eq $null)
        {
        Execute-ProcessAsUser -Path "$envSystemRoot\explorer.exe"
        }

        ## Sleep for 5 Seconds
        Start-Sleep -Seconds 5

        $Users = Get-ChildItem C:\Users
        foreach ($user in $Users){

        ## Cleanup Kingsoft (Local User Profile) Directory
        $KingsoftLocal = "$($user.fullname)\AppData\Local\Kingsoft"
        If (Test-Path $KingsoftLocal) {
        Write-Log -Message "Cleanup ($KingsoftLocal) Directory."
        Remove-Item -Path "$KingsoftLocal" -Force -Recurse -ErrorAction SilentlyContinue 
        }
        ## Cleanup Kingsoft (Roaming User Profile) Directory
        $KingsoftRoaming = "$($user.fullname)\AppData\Roaming\kingsoft"
        If (Test-Path $KingsoftRoaming) {
        Write-Log -Message "Cleanup ($KingsoftRoaming) Directory."
        Remove-Item -Path "$KingsoftRoaming" -Force -Recurse -ErrorAction SilentlyContinue 
        }
        ## Remove WPS Office Start Menu Shortcut From All Profiles
        $StartMenuSC = "$($user.fullname)\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\WPS*"
        If (Test-Path $StartMenuSC) {
        Remove-Item $StartMenuSC -Recurse -Force -ErrorAction SilentlyContinue
        }
        ## Remove WPS Office Desktop Shortcuts From All Profiles
        $DesktopSC = "$($user.fullname)\Desktop\WPS*.lnk"
        If (Test-Path $DesktopSC) {
        Remove-Item $DesktopSC -Recurse -Force -ErrorAction SilentlyContinue
        }
        ## Remove WPS Office TaskBar Shortcut From All Profiles
        $TaskBarSC = "$($user.fullname)\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\WPS Office.lnk"
        If (Test-Path $TaskBarSC) {
        Remove-Item $TaskBarSC -Recurse -Force -ErrorAction SilentlyContinue
        }
        }

        ##*===============================================
        ##* POST-UNINSTALLATION
        ##*===============================================
        [string]$installPhase = 'Post-Uninstallation'
		
		## Create Intune Detection File
		New-Item -Path "C:\ProgramData\WPS_UninstallComplete.flag" -ItemType File -Force | Out-Null


    }
    ElseIf ($deploymentType -ieq 'Repair')
    {
        ##*===============================================
        ##* PRE-REPAIR
        ##*===============================================
        [string]$installPhase = 'Pre-Repair'


        ##*===============================================
        ##* REPAIR
        ##*===============================================
        [string]$installPhase = 'Repair'


        ##*===============================================
        ##* POST-REPAIR
        ##*===============================================
        [string]$installPhase = 'Post-Repair'


    }
    ##*===============================================
    ##* END SCRIPT BODY
    ##*===============================================

    ## Call the Exit-Script function to perform final cleanup operations
    Exit-Script -ExitCode $mainExitCode
}
Catch {
    [int32]$mainExitCode = 60001
    [string]$mainErrorMessage = "$(Resolve-Error)"
    Write-Log -Message $mainErrorMessage -Severity 3 -Source $deployAppScriptFriendlyName
    Show-DialogBox -Text $mainErrorMessage -Icon 'Stop'
    Exit-Script -ExitCode $mainExitCode
}