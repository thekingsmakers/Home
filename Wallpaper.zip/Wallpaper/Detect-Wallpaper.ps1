<#
.SYNOPSIS
    Detection script for Intune Win32 App.
    
.DESCRIPTION
    Returns Exit Code 0 if the wallpaper application is detected (File exists AND Registry matches).
    Returns Exit Code 1 if not detected.
    Writes output for logging.
#>
$ErrorActionPreference = "Stop"

# Expected State
$ExpectedDir = Join-Path -Path $env:APPDATA -ChildPath "CorporateBranding"
$ExpectedFile = Join-Path -Path $ExpectedDir -ChildPath "wallpaper.jpg"

# 1. Check File
if (-not (Test-Path -Path $ExpectedFile)) {
    Write-Output "Miss: Wallpaper file not found at $ExpectedFile"
    Exit 1
}

# 2. Check Registry
$RegPath = "HKCU:\Control Panel\Desktop"
$CurrentWallpaper = (Get-ItemProperty -Path $RegPath -Name Wallpaper -ErrorAction SilentlyContinue).Wallpaper

if ($CurrentWallpaper -ne $ExpectedFile) {
    Write-Output "Miss: Registry wallpaper path ($CurrentWallpaper) does not match expected ($ExpectedFile)"
    Exit 1
    # NOTE: If user changed their wallpaper manually, this script will return Exit 1.
    # Intune will then re-run the install script to enforce the corporate wallpaper again.
    # This is usually DESIRED behavior for corporate policy.
}

Write-Output "Detected: Corporate wallpaper is applied."
Exit 0
