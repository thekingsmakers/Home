<#
.SYNOPSIS
    Uninstalls the corporate wallpaper.
    
.DESCRIPTION
    1. Removes the local wallpaper file and directory.
    2. Clears the HKCU registry keys for Wallpaper.
    3. Forces a system parameter update to refresh the desktop (reverting to solid color or default).

.NOTES
    Context: Run as Logged-on User
#>
$ErrorActionPreference = "Stop"

# 1. Define Paths
$TargetDir = Join-Path -Path $env:APPDATA -ChildPath "CorporateBranding"
$WallpaperFileName = "wallpaper.jpg"
$TargetWallpaperPath = Join-Path -Path $TargetDir -ChildPath $WallpaperFileName

# 2. Remove Files
if (Test-Path -Path $TargetDir) {
    Write-Output "Removing wallpaper directory: $TargetDir"
    Remove-Item -Path $TargetDir -Recurse -Force -ErrorAction SilentlyContinue
}

# 3. Clear Registry
$RegPath = "HKCU:\Control Panel\Desktop"
Write-Output "Clearing Registry keys..."

# We don't delete the keys entirely as that might cause issues, we just clear the values or reset to standard.
# Resetting 'Wallpaper' to empty string usually results in a black background or default color.
Set-ItemProperty -Path $RegPath -Name "Wallpaper" -Value "" -Force
# Reset Style to 0 (Center) or keep as is? 0 is safe.
Set-ItemProperty -Path $RegPath -Name "WallpaperStyle" -Value "0" -Force
Set-ItemProperty -Path $RegPath -Name "TileWallpaper" -Value "0" -Force

# 4. Refresh Desktop
$Win32Source = @"
using System;
using System.Runtime.InteropServices;
public class Wallpaper {
    public const int SPI_SETDESKWALLPAPER = 20; 
    public const int SPIF_UPDATE_AND_BROADCAST = 0x01 | 0x02;
    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
}
"@

try {
    Add-Type -TypeDefinition $Win32Source -ErrorAction Stop
}
catch {
    # Type might already exist
}

# Refresh with empty string to remove wallpaper
[Wallpaper]::SystemParametersInfo([Wallpaper]::SPI_SETDESKWALLPAPER, 0, "", [Wallpaper]::SPIF_UPDATE_AND_BROADCAST)

Write-Output "Uninstall complete."
Exit 0
