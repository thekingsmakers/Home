<#
.SYNOPSIS
    Deploys a corporate wallpaper to the current user's desktop.
    Designed for Microsoft Intune deployment in User Context.

.DESCRIPTION
    This script performs the following actions:
    1. Detects the "wallpaper.jpg" in the script's directory.
    2. Copies the wallpaper to a persistent local location (%AppData%\CorporateBranding).
    3. Configures HKCU registry keys for Wallpaper, WallpaperStyle (Fill), and TileWallpaper.
    4. Uses the SystemParametersInfo Windows API to force an immediate wallpaper refresh without a logoff/reboot.
    5. Enumerates and logs connected monitor details for inventory/diagnostics.

    Multi-Monitor Strategy:
    - We use "WallpaperStyle = 10" (Fill) which is the most robust setting for mixed resolutions.
    - Windows automatically handles scaling the image to fill each monitor's screen while maintaining aspect ratio.
    - This avoids the complexity and brittleness of manually slicing images for specific monitor coordinates.

.NOTES
    Context: Run as Logged-on User
    Version: 1.0.0
    Author: Endpoint Engineering
#>

# ---------------------------------------------------------------------------
# GLOBAL ERROR HANDLING & PREFERENCES
# ---------------------------------------------------------------------------
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

# ---------------------------------------------------------------------------
# VARIABLES
# ---------------------------------------------------------------------------
# Get the directory where this script is running from (Intune downloads content to a temp folder)
$ScriptDir = $PSScriptRoot
# Fallback for testing in ISE/Console if $PSScriptRoot is empty
if ([string]::IsNullOrWhiteSpace($ScriptDir)) {
    $ScriptDir = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
}

$WallpaperFileName = "wallpaper.jpg"
$SourceWallpaperPath = Join-Path -Path $ScriptDir -ChildPath $WallpaperFileName

# Persistent location for the wallpaper
# Using AppData\Roaming ensures it roams with the user profile if needed, 
# and is safe for standard user write access.
$TargetDir = Join-Path -Path $env:APPDATA -ChildPath "CorporateBranding"
$TargetWallpaperPath = Join-Path -Path $TargetDir -ChildPath $WallpaperFileName

# ---------------------------------------------------------------------------
# API DEFINITION (P/Invoke)
# ---------------------------------------------------------------------------
# We need to call user32.dll SystemParametersInfo to notify the shell that the wallpaper has changed.
# This avoids needing a reboot or logoff.
$Win32Source = @"
using System;
using System.Runtime.InteropServices;

public class Wallpaper {
    // SPI_SETDESKWALLPAPER = 0x0014
    public const int SPI_SETDESKWALLPAPER = 20; 
    // SPIF_UPDATEINIFILE = 0x01 (Updates user profile)
    // SPIF_SENDWININICHANGE = 0x02 (Broadcasts change to all top-level windows)
    public const int SPIF_UPDATE_AND_BROADCAST = 0x01 | 0x02;

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
}
"@

# ---------------------------------------------------------------------------
# EXECUTION
# ---------------------------------------------------------------------------

try {
    Write-Output "Starting Wallpaper Deployment..."
    Write-Output "Script Directory: $ScriptDir"

    # 1. VALIDATION
    if (-not (Test-Path -Path $SourceWallpaperPath)) {
        Throw "Source wallpaper not found at: $SourceWallpaperPath. Ensure the image is packaged with the script."
    }

    # 2. FILE COPY
    # Create the directory if it doesn't exist
    if (-not (Test-Path -Path $TargetDir)) {
        Write-Output "Creating target directory: $TargetDir"
        New-Item -Path $TargetDir -ItemType Directory -Force | Out-Null
    }

    # Verify if we need to copy (checking hash could be added, but overwrite is simpler for updates)
    Write-Output "Copying wallpaper to: $TargetWallpaperPath"
    Copy-Item -Path $SourceWallpaperPath -Destination $TargetWallpaperPath -Force

    # 3. REGISTRY CONFIGURATION
    # HKCU\Control Panel\Desktop
    $RegPath = "HKCU:\Control Panel\Desktop"
    
    Write-Output "Configuring Registry keys at $RegPath"
    
    # Wallpaper: Full path to the file
    Set-ItemProperty -Path $RegPath -Name "Wallpaper" -Value $TargetWallpaperPath -Type String -Force

    # WallpaperStyle: 10 = Fill (Best for multi-monitor)
    # Other values: 0=Center, 2=Stretch, 6=Fit, 10=Fill, 22=Span
    Set-ItemProperty -Path $RegPath -Name "WallpaperStyle" -Value "10" -Type String -Force

    # TileWallpaper: 0 = No Tiling
    Set-ItemProperty -Path $RegPath -Name "TileWallpaper" -Value "0" -Type String -Force

    # 4. MONITOR DISCOVERY & LOGGING
    Write-Output "`n--- Monitor Inventory & Resolution Check ---"
    
    $Monitors = Get-CimInstance -ClassName Win32_VideoController
    $MaxMonitorWidth = 0
    $MaxMonitorHeight = 0

    foreach ($Monitor in $Monitors) {
        $Width = $Monitor.CurrentHorizontalResolution
        $Height = $Monitor.CurrentVerticalResolution
        
        if ($Width -gt $MaxMonitorWidth) { $MaxMonitorWidth = $Width }
        if ($Height -gt $MaxMonitorHeight) { $MaxMonitorHeight = $Height }

        $Status = if ($Monitor.Status) { $Monitor.Status } else { "Active" }
        Write-Output "Monitor: $($Monitor.Caption) | Resolution: ${Width}x${Height} | Status: $Status"
    }

    # Verify Image Resolution
    try {
        Add-Type -AssemblyName System.Drawing
        $Img = [System.Drawing.Image]::FromFile($SourceWallpaperPath)
        $ImgWidth = $Img.Width
        $ImgHeight = $Img.Height
        $Img.Dispose()

        Write-Output "Wallpaper Image Resolution: $($ImgWidth)x$($ImgHeight)"

        if ($ImgWidth -lt $MaxMonitorWidth -or $ImgHeight -lt $MaxMonitorHeight) {
            Write-Warning "QUALITY ALERT: The wallpaper ($($ImgWidth)x$($ImgHeight)) is smaller than the largest monitor ($($MaxMonitorWidth)x$($MaxMonitorHeight))."
            Write-Warning "Windows will upscale the image using 'Fill' mode, which may cause blurriness."
            Write-Warning "RECOMMENDATION: Use a source image of at least ${MaxMonitorWidth}x${MaxMonitorHeight} for best results."
        }
        else {
            Write-Output "Quality Check: PASS. Image is large enough for all detected monitors."
        }
    }
    catch {
        Write-Warning "Could not load System.Drawing to verify image resolution. Proceeding anyway."
    }
    
    # Note: Dedicated multi-monitor handling logic in PowerShell without external tools is complex.
    # We rely on 'WallpaperStyle = 10' (Fill) which tells Windows to handle the scaling per monitor automatically.
    # This is the industry standard for idempotent deployments.

    # 5. APPLY SETTINGS
    Write-Output "`nApplying wallpaper..."
    
    # Compile the C# definition
    # Try-Catch around Add-Type in case it's already added in the session (idempotency)
    try {
        Add-Type -TypeDefinition $Win32Source -ErrorAction Stop
    }
    catch {
        Write-Warning "Type already added or compilation failed. Assuming Type exists if previously run in this session."
    }

    # Call the API
    $Result = [Wallpaper]::SystemParametersInfo(
        [Wallpaper]::SPI_SETDESKWALLPAPER, 
        0, 
        $TargetWallpaperPath, 
        [Wallpaper]::SPIF_UPDATE_AND_BROADCAST
    )

    if ($Result -eq 1) {
        Write-Output "Wallpaper successfully applied."
    }
    else {
        Write-Error "SystemParametersInfo returned 0. Failed to update wallpaper."
    }

    Write-Output "Done."
    Exit 0

}
catch {
    Write-Error "An error occurred: $_"
    Exit 1
}
